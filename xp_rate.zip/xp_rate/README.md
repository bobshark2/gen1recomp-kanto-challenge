# XP Rate for Gen1Recomp

Battle EXP multiplier. This is **not** an Exp. Share — whoever already earned the EXP still earns it, just more or less of it.

## Options

MODS → XP Rate → **XP RATE**

| Setting | Effect |
|---|---|
| 0.50x | Half speed. Nuzlocke / long-route grinding. |
| 0.75x | A bit slower than vanilla. |
| 1.00x | Vanilla (default). |
| 1.25x / 1.50x | Light boost. |
| 1.75x / 2.00x | Fast story pace. |

Steps are 0.25 from 0.50 to 2.00.

A 1-EXP knockout still pays at least 1 so half-rate cannot zero a reward.

## Install

Copy `xp_rate` into Gen1Recomp `mods/` (or import the zip) and enable it. Works on Red, Blue, Yellow, and the Gen 2 games if that hook is live.

Safe next to `rr_style_ai` and `rr_boss_teams`. If another EXP mod also wraps `exp.gain`, both multiply — don’t stack 2.00x with a second booster unless you mean to.
