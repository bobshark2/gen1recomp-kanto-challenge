-- XP Rate for Gen1Recomp
-- Scales the EXP number the engine already computed.
-- Does not change who participates and does not add a share item.

return function(mod)
  -- Engine contract: array of rows, key + type in {toggle,choice,number,text}.
  -- choice entries are { label, storedValue }.
  mod.options:define({
    {
      key = "rate",
      type = "choice",
      label = "XP RATE",
      default = 1.00,
      choices = {
        { "0.50x", 0.50 },
        { "0.75x", 0.75 },
        { "1.00x", 1.00 },
        { "1.25x", 1.25 },
        { "1.50x", 1.50 },
        { "1.75x", 1.75 },
        { "2.00x", 2.00 },
      },
    },
  })

  local function multiplier()
    local raw = 1
    if mod.options and mod.options.get then
      raw = mod.options:get("rate")
    end
    return tonumber(raw) or 1
  end

  mod.hooks:wrap("exp.gain", function(next, ctx)
    local exp = next(ctx)
    local n = tonumber(exp) or 0
    if n <= 0 then return exp end
    local scaled = math.floor(n * multiplier() + 0.5)
    if scaled < 1 then scaled = 1 end
    return scaled
  end)

  mod.log:info("xp_rate: battle EXP multiplier armed")
end
