# RR-Style Boss Teams for Gen1Recomp (RBY)

Supplement to **RR-Style Trainer AI**. This mod only changes *who* the bosses send out and *what they know*. Enable both.

Fairly difficult. Every gym has a coverage mon or coverage TM so the sign type is no longer a free win. Brock and Misty stay three mons at vanilla-ish levels.

## Design rules

- **Brock / Misty:** three mons, vanilla levels, no Thunder Wave, no Onix Earthquake. Coverage is a fossil (Kabuto) and an Ice/Psychic chip (Seel + Psybeam).
- **Surge onward:** the old type answer still works on most of the team, but one mon or one TM exists to punish it.
- **Koga → Champion:** full RBY-legal sets, +0 to +2 levels, not +10.
- No species outside the original 151. No held items.
- Yellow Surge’s solo Raichu becomes the same three-mon core as Red/Blue.

## What changes

| Fight | Vanilla feel | This mod |
|---|---|---|
| Brock | Geodude / Onix | Geodude + Kabuto + Onix. Kabuto resists Water and clicks Absorb / Water Gun. Bind Onix. Grass still 2× Kabuto and 4× the rocks. |
| Misty | Staryu / Starmie | Adds Seel (Aurora Beam + Rest). Starmie has Psybeam. No Thunder Wave. |
| Rival 2 | Pidgey + starter | Same two, +0–1 level, real early STAB. |
| Rival 3 | 4 mons | Same four. Abra is still Abra. Starter has its basic STAB, not midgame TMs. |
| Surge | 3 electrics | Magnemite + Voltorb + Raichu. Raichu knows **Surf**. Ground is no longer a wash. |
| Erika | 3 grass | Five grasses, Spore Parasect, Wrap + Sleep everywhere. Acid for Fire-neutral chip. |
| Koga | 4 poison | Adds Pinsir (Bug is 2× Psychic in Gen 1). Weezing has Fire Blast. Explosion still exists. |
| Sabrina | 4 psychic | Adds Slowbro (Surf + Amnesia + T-Wave). Alakazam Recover remains the ace. |
| Blaine | 4 fire | Adds Magmar. Growlithe / Arcanine know Dig. Rapidash Fire Spin. |
| Giovanni Hideout | Onix / Rhyhorn / Kanga (Persian in Yellow) | Same core + Dugtrio. Bind + Earthquake Onix, Body Slam + Rock Slide Rhyhorn, Body Slam / Counter ace (Slash + Thunderbolt on Persian). Ace ~31. Water and Grass still crush it. |
| Giovanni Silph | 4 mons, empty movepools | Five mons. Horn Drill Nidorino, Earthquake Rhyhorn / Dugtrio, Nidoqueen with Earthquake / Thunderbolt / Ice Beam. Ace ~43. Psychic, Water, and Ice still win. |
| Giovanni Gym | 5 Ground | Earthquake + coverage on the Nido pair and Rhydon. |
| Lorelei → Lance | E4 | Ice / Fighting / Ghost / Dragon cores with Blizzard, Psychic, Wrap, Thunderbolt coverage. |
| Champion | 6 | Vanilla structure, OU-flavored RBY sets, +1 level. |

Rival fights after Cerulean (SS Anne, Tower, Silph, Route 22 rematch, Champion) scale up with the game.

## Install

1. Copy `rr_boss_teams` into Gen1Recomp `mods/` (or import the zip).
2. Enable it **and** `rr_style_ai` if you want the brain on these teams.
3. Works on Red, Blue, and Yellow.

If another mod also replaces gym parties, load order matters. This one is priority 70.
