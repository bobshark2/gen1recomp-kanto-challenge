-- RR-Style Boss Teams for Gen1Recomp RBY
-- Rewrites gym / Giovanni / rival / E4 parties and moves.
-- Early fights stay small and legal. Later fights get coverage.
-- Custom moves ride trainer.party (slot.moves wins over boss-move tables).

return function(mod)
  local function M(species, level, moves)
    return { species = species, level = level, moves = moves }
  end

  -- Identify the rival's starter from a built party.
  local function rivalStarter(party)
    if type(party) ~= "table" then return nil end
    for _, slot in ipairs(party) do
      local s = slot and slot.species
      if s == "SQUIRTLE" or s == "WARTORTLE" or s == "BLASTOISE" then return "WATER" end
      if s == "BULBASAUR" or s == "IVYSAUR" or s == "VENUSAUR" then return "GRASS" end
      if s == "CHARMANDER" or s == "CHARMELEON" or s == "CHARIZARD" then return "FIRE" end
      if s == "EEVEE" then return "EEVEE" end
      if s == "VAPOREON" then return "WATER" end
      if s == "JOLTEON" then return "ELECTRIC" end
      if s == "FLAREON" then return "FIRE" end
    end
    return nil
  end

  local function lvl(party, i, fallback)
    local slot = type(party) == "table" and party[i]
    return (slot and tonumber(slot.level)) or fallback
  end

  ---------------------------------------------------------------------
  -- Gyms. Brock / Misty stay small. Everyone gets a coverage answer.
  ---------------------------------------------------------------------
  local function brock(party)
    local g = lvl(party, 1, 12)
    local o = lvl(party, 2, 14)
    -- Yellow 10/12 stays low. Kabuto is the Water-resist fossil so
    -- Water Gun is no longer a free two-shot of the whole gym.
    return {
      M("GEODUDE", g, { "TACKLE", "DEFENSE_CURL", "ROCK_THROW", "MEGA_PUNCH" }),
      M("KABUTO",  math.max(g, 12), { "SCRATCH", "HARDEN", "ABSORB", "WATER_GUN" }),
      M("ONIX",    o, { "BIND", "ROCK_THROW", "BIDE", "SLAM" }),
    }
  end

  local function misty(party)
    local a = lvl(party, 1, 18)
    local b = lvl(party, 2, 21)
    -- No Thunder Wave. Seel + Psybeam are the Grass answers.
    return {
      M("STARYU",  a, { "TACKLE", "WATER_GUN", "BUBBLEBEAM", "HARDEN" }),
      M("SEEL",    math.max(a, 19), { "HEADBUTT", "AURORA_BEAM", "GROWL", "REST" }),
      M("STARMIE", b, { "BUBBLEBEAM", "WATER_GUN", "PSYBEAM", "SWIFT" }),
    }
  end

  -- Route 22, first rival. Two mons.
  local function rival2(party)
    local kind = rivalStarter(party)
    local pLv = lvl(party, 1, 9)
    local sLv = lvl(party, 2, 8)
    local pidgey = M("PIDGEY", pLv, { "GUST", "SAND_ATTACK", "QUICK_ATTACK" })
    if kind == "WATER" then
      return { pidgey, M("SQUIRTLE", sLv, { "TACKLE", "TAIL_WHIP", "BUBBLE", "WATER_GUN" }) }
    elseif kind == "GRASS" then
      return { pidgey, M("BULBASAUR", sLv, { "TACKLE", "GROWL", "LEECH_SEED", "VINE_WHIP" }) }
    elseif kind == "FIRE" then
      return { pidgey, M("CHARMANDER", sLv, { "SCRATCH", "GROWL", "EMBER" }) }
    elseif kind == "EEVEE" then
      return { pidgey, M("EEVEE", sLv, { "TACKLE", "SAND_ATTACK", "QUICK_ATTACK" }) }
    end
    return party
  end

  -- Cerulean rival. Four mons. Abra stays a joke with Teleport + Confusion.
  local function rival3(party)
    local kind = rivalStarter(party)
    local a = lvl(party, 1, 18)
    local b = lvl(party, 2, 15)
    local c = lvl(party, 3, 15)
    local d = lvl(party, 4, 17)
    local lead = M("PIDGEOTTO", a, { "GUST", "QUICK_ATTACK", "SAND_ATTACK", "WHIRLWIND" })
    local abra = M("ABRA", b, { "TELEPORT", "CONFUSION" })
    local rat  = M("RATTATA", c, { "TACKLE", "QUICK_ATTACK", "TAIL_WHIP", "HYPER_FANG" })
    if kind == "WATER" then
      return { lead, abra, rat, M("SQUIRTLE", d, { "TACKLE", "BUBBLE", "WATER_GUN", "BITE" }) }
    elseif kind == "GRASS" then
      return { lead, abra, rat, M("IVYSAUR", d, { "TACKLE", "LEECH_SEED", "VINE_WHIP", "POISONPOWDER" }) }
    elseif kind == "FIRE" then
      return { lead, abra, rat, M("CHARMELEON", d, { "SCRATCH", "EMBER", "LEER", "RAGE" }) }
    elseif kind == "EEVEE" then
      return { lead, abra, rat, M("EEVEE", d, { "TACKLE", "QUICK_ATTACK", "SAND_ATTACK", "BITE" }) }
    end
    return party
  end

  ---------------------------------------------------------------------
  -- Mid
  ---------------------------------------------------------------------
  local function surge(party)
    -- Surf on Raichu is the Ground answer. Selfdestruct punishes a stall.
    local raichuLv = 24
    if type(party) == "table" and #party == 1 then
      raichuLv = lvl(party, 1, 28)
    else
      raichuLv = lvl(party, 3, 24)
    end
    return {
      M("VOLTORB",   math.max(21, raichuLv - 5), { "THUNDERBOLT", "SONICBOOM", "SCREECH", "SELFDESTRUCT" }),
      M("MAGNEMITE", math.max(21, raichuLv - 4), { "THUNDERBOLT", "THUNDER_WAVE", "SONICBOOM", "TACKLE" }),
      M("RAICHU",    raichuLv, { "THUNDERBOLT", "THUNDER_WAVE", "QUICK_ATTACK", "SURF" }),
    }
  end

  local function erika(party)
    return {
      M("WEEPINBELL", 26, { "VINE_WHIP", "WRAP", "SLEEP_POWDER", "STUN_SPORE" }),
      M("TANGELA",    26, { "BIND", "MEGA_DRAIN", "SLEEP_POWDER", "STUN_SPORE" }),
      M("PARASECT",   28, { "SPORE", "MEGA_DRAIN", "SLASH", "STUN_SPORE" }),
      M("VICTREEBEL", 30, { "RAZOR_LEAF", "WRAP", "SLEEP_POWDER", "ACID" }),
      M("VILEPLUME",  30, { "PETAL_DANCE", "SLEEP_POWDER", "MEGA_DRAIN", "ACID" }),
    }
  end

  local function koga(party)
    return {
      M("KOFFING",  37, { "SLUDGE", "SMOG", "SMOKESCREEN", "EXPLOSION" }),
      M("MUK",      39, { "SLUDGE", "DISABLE", "MINIMIZE", "BODY_SLAM" }),
      M("VENOMOTH", 40, { "PSYCHIC", "SLEEP_POWDER", "STUN_SPORE", "MEGA_DRAIN" }),
      M("PINSIR",   41, { "SUBMISSION", "BODY_SLAM", "SEISMIC_TOSS", "SWORDS_DANCE" }),
      M("WEEZING",  43, { "SLUDGE", "TOXIC", "EXPLOSION", "FIRE_BLAST" }),
    }
  end

  local function sabrina(party)
    return {
      M("KADABRA",  38, { "PSYCHIC", "RECOVER", "THUNDER_WAVE", "DISABLE" }),
      M("MR_MIME",  37, { "PSYCHIC", "THUNDER_WAVE", "LIGHT_SCREEN", "SEISMIC_TOSS" }),
      M("VENOMOTH", 38, { "PSYCHIC", "SLEEP_POWDER", "STUN_SPORE", "MEGA_DRAIN" }),
      M("SLOWBRO",  40, { "SURF", "PSYCHIC", "AMNESIA", "THUNDER_WAVE" }),
      M("ALAKAZAM", 44, { "PSYCHIC", "RECOVER", "THUNDER_WAVE", "SEISMIC_TOSS" }),
    }
  end

  local function blaine(party)
    return {
      M("GROWLITHE", 42, { "FLAMETHROWER", "BITE", "BODY_SLAM", "DIG" }),
      M("PONYTA",    40, { "FIRE_SPIN", "STOMP", "TAIL_WHIP", "AGILITY" }),
      M("MAGMAR",    44, { "FIRE_BLAST", "BODY_SLAM", "CONFUSE_RAY", "MEGA_PUNCH" }),
      M("RAPIDASH",  44, { "FIRE_BLAST", "FIRE_SPIN", "BODY_SLAM", "AGILITY" }),
      M("ARCANINE",  48, { "FIRE_BLAST", "BODY_SLAM", "HYPER_BEAM", "DIG" }),
    }
  end

  ---------------------------------------------------------------------
  -- Giovanni
  -- Hideout / Silph are the Rocket fights (too easy in vanilla).
  -- Gym stays the Earth Badge set.
  -- Detect by species so Yellow Persian swaps still land on the right fight.
  ---------------------------------------------------------------------
  local function partyHas(party, species)
    if type(party) ~= "table" then return false end
    for _, slot in ipairs(party) do
      if slot and slot.species == species then return true end
    end
    return false
  end

  local function normalAce(party, level, movesKanga, movesPersian)
    if partyHas(party, "PERSIAN") then
      return M("PERSIAN", level, movesPersian)
    end
    return M("KANGASKHAN", level, movesKanga)
  end

  -- Post-Erika, ~Lv 28-32 box. Water / Grass / Fighting all exist.
  -- +1 mon, +2 on the ace, TMs you can already buy in Celadon.
  local function giovanniHideout(party)
    local aceLv = math.max(lvl(party, 3, 29), 31)
    return {
      M("ONIX",    math.max(lvl(party, 1, 25), 26),
        { "ROCK_THROW", "BIND", "BIDE", "EARTHQUAKE" }),
      M("RHYHORN", math.max(lvl(party, 2, 24), 26),
        { "STOMP", "HORN_ATTACK", "BODY_SLAM", "ROCK_SLIDE" }),
      M("DUGTRIO", 27, { "DIG", "SLASH", "SAND_ATTACK", "BODY_SLAM" }),
      normalAce(party, aceLv,
        { "BODY_SLAM", "BITE", "MEGA_PUNCH", "COUNTER" },
        { "SLASH", "BITE", "BUBBLEBEAM", "THUNDERBOLT" }),
    }
  end

  -- Mid-Silph. Player often has Lapras + Dig + a Psychic.
  -- Five mons, coverage on the Nidos, still a Water / Ice / Psychic hole.
  local function giovanniSilph(party)
    local aceLv = math.max(lvl(party, 4, 41), 43)
    return {
      M("NIDORINO", math.max(lvl(party, 1, 37), 38),
        { "HORN_DRILL", "DOUBLE_KICK", "TOXIC", "BODY_SLAM" }),
      normalAce(party, math.max(lvl(party, 2, 35), 37),
        { "BODY_SLAM", "BITE", "HYPER_BEAM", "EARTHQUAKE" },
        { "SLASH", "BITE", "THUNDERBOLT", "HYPER_BEAM" }),
      M("RHYHORN", math.max(lvl(party, 3, 37), 39),
        { "EARTHQUAKE", "ROCK_SLIDE", "HORN_DRILL", "BODY_SLAM" }),
      M("DUGTRIO", 39, { "EARTHQUAKE", "SLASH", "SAND_ATTACK", "DIG" }),
      M("NIDOQUEEN", aceLv,
        { "EARTHQUAKE", "THUNDERBOLT", "ICE_BEAM", "BODY_SLAM" }),
    }
  end

  local function giovanniGym(party)
    return {
      M("RHYHORN",    lvl(party, 1, 45), { "EARTHQUAKE", "HORN_DRILL", "ROCK_SLIDE", "BODY_SLAM" }),
      M("DUGTRIO",    lvl(party, 2, 42), { "EARTHQUAKE", "SLASH", "SAND_ATTACK", "DIG" }),
      M("NIDOQUEEN",  lvl(party, 3, 44), { "EARTHQUAKE", "THUNDERBOLT", "ICE_BEAM", "TOXIC" }),
      M("NIDOKING",   lvl(party, 4, 45), { "EARTHQUAKE", "BLIZZARD", "THUNDERBOLT", "BODY_SLAM" }),
      M("RHYDON",     lvl(party, 5, 50), { "EARTHQUAKE", "ROCK_SLIDE", "BODY_SLAM", "SURF" }),
    }
  end

  local function giovanni(index, party)
    if partyHas(party, "ONIX") or index == 1 then
      return giovanniHideout(party)
    end
    if partyHas(party, "RHYDON") or partyHas(party, "NIDOKING") then
      return giovanniGym(party)
    end
    if partyHas(party, "NIDORINO") or index == 2 then
      return giovanniSilph(party)
    end
    if index == 3 then return giovanniGym(party) end
    return giovanniSilph(party)
  end

  ---------------------------------------------------------------------
  -- Elite Four
  ---------------------------------------------------------------------
  local function lorelei(party)
    return {
      M("DEWGONG",  lvl(party, 1, 54), { "ICE_BEAM", "SURF", "BODY_SLAM", "REST" }),
      M("CLOYSTER", lvl(party, 2, 53), { "BLIZZARD", "CLAMP", "AURORA_BEAM", "EXPLOSION" }),
      M("SLOWBRO",  lvl(party, 3, 54), { "SURF", "PSYCHIC", "AMNESIA", "THUNDER_WAVE" }),
      M("JYNX",     lvl(party, 4, 56), { "LOVELY_KISS", "BLIZZARD", "PSYCHIC", "BODY_SLAM" }),
      M("LAPRAS",   lvl(party, 5, 56), { "BLIZZARD", "THUNDERBOLT", "SURF", "BODY_SLAM" }),
    }
  end

  local function bruno(party)
    return {
      M("ONIX",       lvl(party, 1, 53), { "ROCK_SLIDE", "EARTHQUAKE", "BIND", "SCREECH" }),
      M("HITMONCHAN", lvl(party, 2, 55), { "ICE_PUNCH", "THUNDERPUNCH", "FIRE_PUNCH", "MEGA_PUNCH" }),
      M("HITMONLEE",  lvl(party, 3, 55), { "HI_JUMP_KICK", "MEGA_KICK", "MEDITATE", "DOUBLE_KICK" }),
      M("ONIX",       56, { "ROCK_SLIDE", "EARTHQUAKE", "EXPLOSION", "BIND" }),
      M("MACHAMP",    lvl(party, 5, 58), { "SUBMISSION", "BODY_SLAM", "EARTHQUAKE", "HYPER_BEAM" }),
    }
  end

  local function agatha(party)
    return {
      M("GENGAR",   lvl(party, 1, 56), { "HYPNOSIS", "DREAM_EATER", "THUNDERBOLT", "MEGA_DRAIN" }),
      M("GOLBAT",   lvl(party, 2, 56), { "CONFUSE_RAY", "WING_ATTACK", "MEGA_DRAIN", "SUPERSONIC" }),
      M("HAUNTER",  lvl(party, 3, 55), { "CONFUSE_RAY", "NIGHT_SHADE", "HYPNOSIS", "MEGA_DRAIN" }),
      M("ARBOK",    lvl(party, 4, 58), { "GLARE", "ACID", "WRAP", "EARTHQUAKE" }),
      M("GENGAR",   lvl(party, 5, 60), { "HYPNOSIS", "PSYCHIC", "THUNDERBOLT", "EXPLOSION" }),
    }
  end

  local function lance(party)
    return {
      M("GYARADOS",   lvl(party, 1, 58), { "HYDRO_PUMP", "THUNDERBOLT", "BODY_SLAM", "HYPER_BEAM" }),
      M("DRAGONAIR",  lvl(party, 2, 56), { "THUNDER_WAVE", "THUNDERBOLT", "SURF", "DRAGON_RAGE" }),
      M("DRAGONAIR",  lvl(party, 3, 56), { "THUNDER_WAVE", "BLIZZARD", "WRAP", "DRAGON_RAGE" }),
      M("AERODACTYL", lvl(party, 4, 60), { "FLY", "HYPER_BEAM", "FIRE_BLAST", "WING_ATTACK" }),
      M("DRAGONITE",  lvl(party, 5, 62), { "BLIZZARD", "THUNDERBOLT", "WRAP", "HYPER_BEAM" }),
    }
  end

  ---------------------------------------------------------------------
  -- Later rival bands (OPP_RIVAL3 / OPP_SONY3)
  -- 1-3 Cerulean (handled as rival3)
  -- 4-6 SS Anne
  -- 7-9 Tower
  -- 10-12 Silph
  -- 13-15 Route 22 rematch
  -- 16-18 Champion
  ---------------------------------------------------------------------
  local function anneTeam(kind, party)
    local p = M("PIDGEOTTO", lvl(party, 1, 19), { "WING_ATTACK", "QUICK_ATTACK", "SAND_ATTACK", "WHIRLWIND" })
    local r = M("RATICATE",  lvl(party, 2, 16), { "HYPER_FANG", "QUICK_ATTACK", "TAIL_WHIP", "FOCUS_ENERGY" })
    local k = M("KADABRA",   lvl(party, 3, 18), { "CONFUSION", "DISABLE", "TELEPORT" })
    if kind == "WATER" then
      return { p, r, k, M("WARTORTLE", lvl(party, 4, 20), { "WATER_GUN", "BITE", "BUBBLE", "TACKLE" }) }
    elseif kind == "GRASS" then
      return { p, r, k, M("IVYSAUR", lvl(party, 4, 20), { "VINE_WHIP", "LEECH_SEED", "POISONPOWDER", "RAZOR_LEAF" }) }
    elseif kind == "FIRE" then
      return { p, r, k, M("CHARMELEON", lvl(party, 4, 20), { "EMBER", "LEER", "RAGE", "SLASH" }) }
    end
    return { p, r, k, M("EEVEE", lvl(party, 4, 20), { "QUICK_ATTACK", "SAND_ATTACK", "BITE", "TACKLE" }) }
  end

  local function towerTeam(kind, party)
    local p = M("PIDGEOTTO", lvl(party, 1, 25), { "WING_ATTACK", "QUICK_ATTACK", "WHIRLWIND", "MIRROR_MOVE" })
    local g = M("GROWLITHE", lvl(party, 2, 23), { "EMBER", "BITE", "LEER", "TAKE_DOWN" })
    local e = M("EXEGGCUTE", lvl(party, 3, 22), { "HYPNOSIS", "BARRAGE", "LEECH_SEED", "STUN_SPORE" })
    local k = M("KADABRA",   lvl(party, 4, 23), { "CONFUSION", "DISABLE", "PSYBEAM", "RECOVER" })
    local starter
    if kind == "WATER" then
      starter = M("WARTORTLE", lvl(party, 5, 25), { "WATER_GUN", "BITE", "WITHDRAW", "BUBBLEBEAM" })
    elseif kind == "GRASS" then
      starter = M("IVYSAUR", lvl(party, 5, 25), { "RAZOR_LEAF", "LEECH_SEED", "POISONPOWDER", "SLEEP_POWDER" })
    elseif kind == "FIRE" then
      starter = M("CHARMELEON", lvl(party, 5, 25), { "FLAMETHROWER", "SLASH", "LEER", "RAGE" })
    else
      starter = M("EEVEE", lvl(party, 5, 25), { "QUICK_ATTACK", "BITE", "SAND_ATTACK", "TAKE_DOWN" })
    end
    return { p, g, e, k, starter }
  end

  local function silphTeam(kind, party)
    local p = M("PIDGEOT",   lvl(party, 1, 37), { "WING_ATTACK", "QUICK_ATTACK", "WHIRLWIND", "MIRROR_MOVE" })
    local a = M("ALAKAZAM",  lvl(party, 2, 35), { "PSYCHIC", "RECOVER", "THUNDER_WAVE", "DISABLE" })
    local n = M("NIDORINO",  lvl(party, 3, 35), { "HORN_ATTACK", "DOUBLE_KICK", "POISON_STING", "FOCUS_ENERGY" })
    local g = M("GROWLITHE", lvl(party, 4, 35), { "FLAMETHROWER", "BITE", "BODY_SLAM", "LEER" })
    local starter
    if kind == "WATER" then
      starter = M("BLASTOISE", lvl(party, 5, 38), { "SURF", "BITE", "BODY_SLAM", "WITHDRAW" })
    elseif kind == "GRASS" then
      starter = M("VENUSAUR", lvl(party, 5, 38), { "RAZOR_LEAF", "SLEEP_POWDER", "LEECH_SEED", "BODY_SLAM" })
    elseif kind == "FIRE" then
      starter = M("CHARIZARD", lvl(party, 5, 38), { "FLAMETHROWER", "SLASH", "WING_ATTACK", "FIRE_SPIN" })
    else
      starter = M("JOLTEON", lvl(party, 5, 38), { "THUNDERBOLT", "THUNDER_WAVE", "PIN_MISSILE", "QUICK_ATTACK" })
    end
    return { p, a, n, g, starter }
  end

  local function route22Rematch(kind, party)
    local p = M("PIDGEOT",    lvl(party, 1, 47), { "WING_ATTACK", "QUICK_ATTACK", "SKY_ATTACK", "MIRROR_MOVE" })
    local r = M("RHYHORN",    lvl(party, 2, 45), { "STOMP", "HORN_DRILL", "FURY_ATTACK", "BODY_SLAM" })
    local g = M("GROWLITHE",  lvl(party, 3, 45), { "FLAMETHROWER", "BODY_SLAM", "BITE", "LEER" })
    local e = M("EXEGGUTOR",  lvl(party, 4, 47), { "SLEEP_POWDER", "PSYCHIC", "MEGA_DRAIN", "STUN_SPORE" })
    local a = M("ALAKAZAM",   lvl(party, 5, 50), { "PSYCHIC", "RECOVER", "THUNDER_WAVE", "SEISMIC_TOSS" })
    local starter
    if kind == "WATER" then
      starter = M("BLASTOISE", lvl(party, 6, 53), { "SURF", "BLIZZARD", "BODY_SLAM", "EARTHQUAKE" })
    elseif kind == "GRASS" then
      starter = M("VENUSAUR", lvl(party, 6, 53), { "RAZOR_LEAF", "SLEEP_POWDER", "BODY_SLAM", "MEGA_DRAIN" })
    elseif kind == "FIRE" then
      starter = M("CHARIZARD", lvl(party, 6, 53), { "FIRE_BLAST", "SLASH", "EARTHQUAKE", "HYPER_BEAM" })
    else
      starter = M("VAPOREON", lvl(party, 6, 53), { "SURF", "ICE_BEAM", "ACID_ARMOR", "BODY_SLAM" })
    end
    return { p, r, g, e, a, starter }
  end

  local function champion(kind, party)
    local p = M("PIDGEOT",   lvl(party, 1, 61), { "SKY_ATTACK", "HYPER_BEAM", "QUICK_ATTACK", "MIRROR_MOVE" })
    local a = M("ALAKAZAM",  lvl(party, 2, 59), { "PSYCHIC", "RECOVER", "THUNDER_WAVE", "SEISMIC_TOSS" })
    local r = M("RHYDON",    lvl(party, 3, 61), { "EARTHQUAKE", "ROCK_SLIDE", "BODY_SLAM", "SURF" })
    local ar = M("ARCANINE", lvl(party, 4, 61), { "FIRE_BLAST", "BODY_SLAM", "HYPER_BEAM", "REFLECT" })
    local ex = M("EXEGGUTOR",lvl(party, 5, 63), { "SLEEP_POWDER", "PSYCHIC", "MEGA_DRAIN", "EXPLOSION" })
    local starter
    if kind == "WATER" then
      starter = M("BLASTOISE", lvl(party, 6, 65), { "SURF", "BLIZZARD", "EARTHQUAKE", "BODY_SLAM" })
    elseif kind == "GRASS" then
      starter = M("VENUSAUR", lvl(party, 6, 65), { "RAZOR_LEAF", "SLEEP_POWDER", "BODY_SLAM", "MEGA_DRAIN" })
    elseif kind == "FIRE" then
      starter = M("CHARIZARD", lvl(party, 6, 65), { "FIRE_BLAST", "EARTHQUAKE", "SLASH", "HYPER_BEAM" })
    else
      -- Yellow champion ace is the Eeveelution they evolved
      local ace = "JOLTEON"
      if type(party) == "table" then
        for _, slot in ipairs(party) do
          if slot and (slot.species == "VAPOREON" or slot.species == "JOLTEON" or slot.species == "FLAREON") then
            ace = slot.species
          end
        end
      end
      if ace == "VAPOREON" then
        starter = M("VAPOREON", lvl(party, 6, 65), { "SURF", "ICE_BEAM", "ACID_ARMOR", "BODY_SLAM" })
      elseif ace == "FLAREON" then
        starter = M("FLAREON", lvl(party, 6, 65), { "FIRE_BLAST", "BODY_SLAM", "HYPER_BEAM", "QUICK_ATTACK" })
      else
        starter = M("JOLTEON", lvl(party, 6, 65), { "THUNDERBOLT", "THUNDER_WAVE", "PIN_MISSILE", "DOUBLE_KICK" })
      end
    end
    return { p, a, r, ar, ex, starter }
  end

  local function rival3Band(index, party)
    local kind = rivalStarter(party)
    if index <= 3 then return rival3(party) end
    if index <= 6 then return anneTeam(kind, party) end
    if index <= 9 then return towerTeam(kind, party) end
    if index <= 12 then return silphTeam(kind, party) end
    if index <= 15 then return route22Rematch(kind, party) end
    return champion(kind, party)
  end

  ---------------------------------------------------------------------
  -- Dispatch
  ---------------------------------------------------------------------
  local function upgrade(class, index, party)
    class = tostring(class or ""):upper()
    index = tonumber(index) or 1

    if class:find("BROCK", 1, true) then return brock(party) end
    if class:find("MISTY", 1, true) then return misty(party) end
    if class:find("SURGE", 1, true) then return surge(party) end
    if class:find("ERIKA", 1, true) then return erika(party) end
    if class:find("KOGA", 1, true)  then return koga(party) end
    if class:find("SABRINA", 1, true) then return sabrina(party) end
    if class:find("BLAINE", 1, true) then return blaine(party) end
    if class:find("GIOVANNI", 1, true) then return giovanni(index, party) end
    if class:find("LORELEI", 1, true) then return lorelei(party) end
    if class:find("BRUNO", 1, true) then return bruno(party) end
    if class:find("AGATHA", 1, true) then return agatha(party) end
    if class:find("LANCE", 1, true) then return lance(party) end

    -- Lab rival: leave vanilla on purpose.
    if class == "OPP_RIVAL1" or class == "OPP_SONY1" or class == "OPP_RIVAL" then
      return party
    end
    -- Route 22 first fight
    if class == "OPP_RIVAL2" or class == "OPP_SONY2" then
      return rival2(party)
    end
    -- All later scripted rival fights live on RIVAL3 / SONY3
    if class == "OPP_RIVAL3" or class == "OPP_SONY3" then
      return rival3Band(index, party)
    end
    return party
  end

  mod.hooks:wrap("trainer.party", function(nextParty, oppClass, partyIndex, party)
    local out = nextParty(oppClass, partyIndex, party) or party
    local upgraded = upgrade(oppClass, partyIndex, out)
    return upgraded or out
  end)

  mod.log:info("rr_boss_teams: gym / Giovanni / rival / E4 parties loaded")
end
