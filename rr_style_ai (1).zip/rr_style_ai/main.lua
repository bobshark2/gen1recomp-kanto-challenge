-- RR-Style Trainer AI for Gen1Recomp RBY
-- Goal: feel like a nasty human on the Gen 1 ruleset.
-- Hooks:
--   trainer.before_battle - snapshot the player's lead
--   trainer.party         - put the best lead first
--   battle.enemy_action   - mid-turn move / hard-switch / item
--   battle.exp_award      - on-faint send-in (swap into first living slot)
-- Wild / link / locked multi-turn actions fall through to vanilla.

return function(mod)
  ---------------------------------------------------------------------
  -- Options
  ---------------------------------------------------------------------
  -- Engine contract: one array of rows. key + type in {toggle,choice,number,text}.
  -- choice values are { label, stored }. define() replaces the whole schema.
  mod.options:define({
    {
      key = "mode",
      type = "choice",
      label = "AI MODE",
      default = "full",
      choices = {
        { "Moves only", "moves" },
        { "Moves + Switch", "switch" },
        { "Full (switch + items)", "full" },
      },
    },
    {
      key = "scope",
      type = "choice",
      label = "APPLY TO",
      default = "bosses",
      choices = {
        { "Gym / E4 / Rival", "bosses" },
        { "All trainers", "all" },
      },
    },
    {
      key = "intensity",
      type = "choice",
      label = "INTENSITY",
      default = "brutal",
      choices = {
        { "Smart", "smart" },
        { "Brutal", "brutal" },
      },
    },
  })

  ---------------------------------------------------------------------
  -- Constants
  ---------------------------------------------------------------------
  local PHYSICAL = {
    NORMAL = true, FIGHTING = true, FLYING = true, POISON = true,
    GROUND = true, ROCK = true, BUG = true, GHOST = true,
  }

  local STAGE_MULT = {
    [-6] = 25, [-5] = 28, [-4] = 33, [-3] = 40, [-2] = 50, [-1] = 66,
    [0] = 100,
    [1] = 150, [2] = 200, [3] = 250, [4] = 300, [5] = 350, [6] = 400,
  }

  local SETUP_EFFECTS = {
    ATTACK_UP1_EFFECT = true, ATTACK_UP2_EFFECT = true,
    DEFENSE_UP1_EFFECT = true, DEFENSE_UP2_EFFECT = true,
    SPEED_UP1_EFFECT = true, SPEED_UP2_EFFECT = true,
    SPECIAL_UP1_EFFECT = true, SPECIAL_UP2_EFFECT = true,
    ACCURACY_UP1_EFFECT = true, EVASION_UP1_EFFECT = true,
    EVASION_UP2_EFFECT = true,
  }

  local SPEED_DOWN_EFFECTS = {
    SPEED_DOWN1_EFFECT = true, SPEED_DOWN2_EFFECT = true,
    SPEED_DOWN_HIT_EFFECT = true,
  }

  local STATUS_EFFECTS = {
    SLEEP_EFFECT = "slp",
    PARALYZE_EFFECT = "par",
    POISON_EFFECT = "psn",
    POISON_HIT_EFFECT = "psn",
    TOXIC_EFFECT = "psn",
    BURN_EFFECT = "brn",
    BURN_HIT_EFFECT = "brn",
    FREEZE_HIT_EFFECT = "frz",
    CONFUSION_EFFECT = "confusion",
    CONFUSE_HIT_EFFECT = "confusion",
  }

  local HEAL_EFFECTS = {
    HEAL_EFFECT = true, REST_EFFECT = true,
  }

  local EXPLODE_EFFECTS = {
    EXPLODE_EFFECT = true,
  }

  local TRAP_EFFECTS = {
    TRAPPING_EFFECT = true, WRAP_EFFECT = true, BIND_EFFECT = true,
    FIRE_SPIN_EFFECT = true, CLAMP_EFFECT = true,
  }

  local SCREEN_EFFECTS = {
    REFLECT_EFFECT = true, LIGHT_SCREEN_EFFECT = true,
  }

  local FIXED_DAMAGE = {
    SONICBOOM = 20, SONIC_BOOM = 20,
    DRAGON_RAGE = 40, DRAGONRAGE = 40,
  }

  local DEAD_MOVES = {
    FOCUS_ENERGY_EFFECT = true, -- Gen 1 Focus Energy is bugged / anti-synergy
  }

  local BOSS_CLASSES = {
    OPP_BROCK = true, OPP_MISTY = true, OPP_LT_SURGE = true,
    OPP_LTSURGE = true, OPP_ERIKA = true, OPP_KOGA = true,
    OPP_SABRINA = true, OPP_BLAINE = true, OPP_GIOVANNI = true,
    OPP_LORELEI = true, OPP_BRUNO = true, OPP_AGATHA = true,
    OPP_LANCE = true, OPP_RIVAL1 = true, OPP_RIVAL2 = true,
    OPP_RIVAL3 = true, OPP_SONY1 = true, OPP_SONY2 = true,
    OPP_SONY3 = true, OPP_RIVAL = true, OPP_PROF_OAK = true,
  }

  local POTIONS = {
    POTION = 20, SUPER_POTION = 50, HYPER_POTION = 200,
    FULL_RESTORE = 9999, FRESH_WATER = 50, SODA_POP = 60, LEMONADE = 80,
  }

  -- Gen 1 damage roll is 217..255 / 255. Min roll is the guaranteed floor.
  local MIN_ROLL = 217 / 255

  ---------------------------------------------------------------------
  -- Options / class helpers
  ---------------------------------------------------------------------
  local pendingPlayerLead = nil
  local switchedThisMon = {}
  local switchCount = {}

  local function opt(id, fallback)
    if mod.options and mod.options.get then
      return mod.options:get(id) or fallback
    end
    return fallback
  end

  local function modeOf() return opt("mode", "full") end
  local function brutal() return opt("intensity", "brutal") == "brutal" end

  local function classNameOf(class)
    return tostring(class or ""):upper()
  end

  local function isBossClass(c)
    c = classNameOf(c)
    if BOSS_CLASSES[c] then return true end
    if c:find("RIVAL", 1, true) or c:find("SONY", 1, true) then return true end
    if c:find("BROCK") or c:find("MISTY") or c:find("SURGE") then return true end
    if c:find("ERIKA") or c:find("KOGA") or c:find("SABRINA") then return true end
    if c:find("BLAINE") or c:find("GIOVANNI") then return true end
    if c:find("LORELEI") or c:find("BRUNO") or c:find("AGATHA") or c:find("LANCE") then return true end
    return false
  end

  local function trainerClass(battle)
    local t = battle.trainer or {}
    return t.class or t.id or t.trainerClass or battle.trainerClass
  end

  local function enabledFor(battle)
    if opt("scope", "bosses") == "all" then return true end
    return isBossClass(trainerClass(battle))
  end

  ---------------------------------------------------------------------
  -- Battler / mon helpers
  ---------------------------------------------------------------------
  local function hpFrac(battler)
    local mon = battler and battler.mon
    if not mon then return 1 end
    local max = (mon.stats and mon.stats.hp) or mon.maxHp or mon.maxHP or 0
    local hp = mon.hp or max
    if max <= 0 then return 1 end
    return hp / max
  end

  local function hpCur(battler)
    local mon = battler and battler.mon
    return (mon and mon.hp) or 0
  end

  local function hpMax(battler)
    local mon = battler and battler.mon
    if not mon then return 1 end
    return (mon.stats and mon.stats.hp) or mon.maxHp or mon.maxHP or 1
  end

  local function speciesTypes(data, mon)
    if not mon then return {} end
    if type(mon.types) == "table" then return mon.types end
    if mon.type1 then return { mon.type1, mon.type2 } end
    local def = data and data.pokemon and data.pokemon[mon.species]
    if not def then return {} end
    if type(def.types) == "table" then return def.types end
    if def.type1 then return { def.type1, def.type2 } end
    return {}
  end

  local function typesOf(battler, data)
    if not battler then return {} end
    if type(battler.curTypes) == "table" then return battler.curTypes end
    return speciesTypes(data, battler.mon or battler)
  end

  local function statusOf(battler)
    local mon = battler and battler.mon
    local s = mon and mon.status
    if type(s) == "string" then return s:lower() end
    return nil
  end

  local function levelOf(battler)
    local mon = battler and battler.mon
    return tonumber(mon and mon.level) or 50
  end

  local function stagesOf(battler)
    local mon = battler and battler.mon
    return (battler and battler.stages) or (mon and mon.stages) or {}
  end

  local function stageVal(battler, which)
    local st = stagesOf(battler)
    return tonumber(st[which]) or tonumber(st[which:upper()]) or 0
  end

  local function rawStat(battler, which)
    local mon = battler and battler.mon or {}
    local stats = mon.stats or battler.stats or {}
    local aliases = {
      attack = { "attack", "atk", "ATTACK" },
      defense = { "defense", "def", "DEFENSE" },
      speed = { "speed", "spd", "SPEED" },
      special = { "special", "spa", "spdSpec", "SPECIAL" },
    }
    for _, key in ipairs(aliases[which] or { which }) do
      if tonumber(stats[key]) then return tonumber(stats[key]) end
    end
    if tonumber(battler[which]) then return tonumber(battler[which]) end
    return 100
  end

  local function stagedStat(battler, which)
    local base = rawStat(battler, which)
    local st = stageVal(battler, which)
    if st > 6 then st = 6 elseif st < -6 then st = -6 end
    return math.floor(base * (STAGE_MULT[st] or 100) / 100)
  end

  local function speedOf(battler)
    local spd = stagedStat(battler, "speed")
    if statusOf(battler) == "par" then
      spd = math.max(1, math.floor(spd / 4))
    end
    return spd
  end

  local function boostSum(battler)
    local n = 0
    for _, k in ipairs({ "attack", "defense", "speed", "special", "accuracy", "evasion" }) do
      local v = stageVal(battler, k)
      if v > 0 then n = n + v end
    end
    return n
  end

  local function hasScreen(battler, name)
    if not battler then return false end
    if battler[name] then return true end
    if battler.screens and battler.screens[name] then return true end
    return false
  end

  ---------------------------------------------------------------------
  -- Type chart
  ---------------------------------------------------------------------
  local function effectiveness(data, moveType, defTypes)
    if not moveType or type(defTypes) ~= "table" then return 1 end
    local chart = data and data.type_chart
    local matchups = chart and (chart.matchups or chart.rows)
    if type(matchups) ~= "table" then return 1 end
    local mult = 1
    for _, row in ipairs(matchups) do
      local atk = row.attacker or row.from or row.type
      local def = row.defender or row.into or row.target
      local m = row.multiplier or row.mult
      if atk == moveType and (def == defTypes[1] or def == defTypes[2]) then
        if type(m) == "number" and m > 4 then
          mult = mult * (m / 10)
        elseif type(m) == "number" then
          mult = mult * m
        end
      end
    end
    return mult
  end

  ---------------------------------------------------------------------
  -- Damage estimate
  -- Incoming threats use the pre-roll (? max). Outgoing KOs use min roll
  -- so the AI only treats a KO as real when 217/255 still kills.
  ---------------------------------------------------------------------
  local function isPhysical(moveType)
    return PHYSICAL[moveType] == true
  end

  local function estimateDamage(data, user, target, def, opts)
    opts = opts or {}
    if type(def) ~= "table" then return 0 end
    local moveType = def.type
    local eff = effectiveness(data, moveType, typesOf(target, data))
    if eff <= 0 then return 0 end

    local effect = def.effect
    if effect == "OHKO_EFFECT" then
      if speedOf(user) > speedOf(target) then return hpMax(target) end
      return 0
    end
    if effect == "SPECIAL_DAMAGE_EFFECT" then
      local id = def.id or ""
      if FIXED_DAMAGE[id] then return FIXED_DAMAGE[id] end
      return levelOf(user)
    end
    if effect == "SUPER_FANG_EFFECT" then
      return math.max(1, math.floor(hpCur(target) / 2))
    end
    if effect == "COUNTER_EFFECT" then
      return 0 -- scored separately from lastMove
    end

    local power = tonumber(def.power) or 0
    if power <= 0 then return 0 end

    local atk, defn
    local special = not isPhysical(moveType)
    if special then
      atk = stagedStat(user, "special")
      defn = stagedStat(target, "special")
      if hasScreen(target, "lightScreen") then defn = defn * 2 end
    else
      atk = stagedStat(user, "attack")
      defn = stagedStat(target, "defense")
      if statusOf(user) == "brn" then
        atk = math.max(1, math.floor(atk / 2))
      end
      if hasScreen(target, "reflect") then defn = defn * 2 end
    end
    defn = math.max(1, defn)

    local L = levelOf(user)
    local base = math.floor(math.floor(math.floor(2 * L / 5 + 2) * power * atk / defn) / 50) + 2

    local stab = 1
    for _, t in ipairs(typesOf(user, data)) do
      if t == moveType then stab = 1.5; break end
    end
    local dmg = math.floor(base * stab * eff)
    if opts.minRoll then
      dmg = math.floor(dmg * MIN_ROLL)
    end
    if target.substitute or target.hasSubstitute then
      -- still "hits" the sub; treat as real damage for pressure
    end
    return dmg
  end

  local function hitsToKO(dmg, target)
    local hp = hpCur(target)
    if dmg <= 0 then return 99 end
    return math.ceil(hp / dmg)
  end

  local function guaranteedKO(data, user, target, def)
    return estimateDamage(data, user, target, def, { minRoll = true }) >= hpCur(target)
        and hpCur(target) > 0
  end

  ---------------------------------------------------------------------
  -- Kit inspection
  ---------------------------------------------------------------------
  local function moveList(battler)
    if battler and type(battler.curMoves) == "table" then return battler.curMoves end
    local mon = battler and battler.mon
    return (mon and mon.moves) or {}
  end

  local function kitHas(data, battler, pred)
    local defs = data and data.moves
    if not defs then return false end
    for _, mv in ipairs(moveList(battler)) do
      local id = type(mv) == "table" and mv.id or mv
      local def = defs[id]
      if def and pred(def, mv) then return true end
    end
    return false
  end

  local function playerThreatensSetup(battle)
    return kitHas(battle.data, battle.player, function(def)
      return SETUP_EFFECTS[def.effect] == true
    end)
  end

  local function bestPlayerAttack(battle)
    local p, e = battle.player, battle.enemy
    local defs = battle.data and battle.data.moves
    if not (p and e and defs) then return nil, 0, nil end
    local best, bestDmg, bestDef
    for i, mv in ipairs(p.curMoves or {}) do
      if p.disabledSlot ~= i and (mv.pp or 1) > 0 then
        local def = defs[mv.id]
        if def then
          local dmg = estimateDamage(battle.data, p, e, def)
          if not bestDmg or dmg > bestDmg then
            best, bestDmg, bestDef = mv, dmg, def
          end
        end
      end
    end
    return best, bestDmg or 0, bestDef
  end

  local function predictedPlayerMove(battle)
    local mv, dmg = bestPlayerAttack(battle)
    return mv, dmg
  end

  local function usableMoves(battle)
    local e = battle.enemy
    local out = {}
    if not (e and type(e.curMoves) == "table") then return out end
    local unlimited = battle.ruleset and battle.ruleset.enemyUnlimitedPP
    for i, mv in ipairs(e.curMoves) do
      if e.disabledSlot ~= i and (unlimited or (mv.pp or 0) > 0) then
        out[#out + 1] = { slot = i, mv = mv }
      end
    end
    return out
  end

  ---------------------------------------------------------------------
  -- Move scoring
  ---------------------------------------------------------------------
  local function scoreMove(battle, mv)
    local defs = battle.data and battle.data.moves
    local def = defs and defs[mv.id]
    if not def then return -1 end
    local e, p = battle.enemy, battle.player
    local data = battle.data
    local effect = def.effect
    local acc = tonumber(def.accuracy) or 100
    local myHp = hpFrac(e)
    local theirHp = hpFrac(p)
    local theirStatus = statusOf(p)
    local weOutspeed = speedOf(e) > speedOf(p)
    local _, predDmg, predDef = bestPlayerAttack(battle)
    local theyOHKO = predDmg >= hpCur(e)
    local they2HKO = predDmg * 2 >= hpCur(e)
    local playerBoosted = boostSum(p) >= 2
    local playerCanSetup = playerThreatensSetup(battle)
    local dmgMax = estimateDamage(data, e, p, def)
    local dmgMin = estimateDamage(data, e, p, def, { minRoll = true })
    local eff = effectiveness(data, def.type, typesOf(p, data))

    if DEAD_MOVES[effect] then return 0 end

    -- Dream Eater only if they are asleep
    if effect == "DREAM_EATER_EFFECT" then
      if theirStatus ~= "slp" then return 0 end
      if dmgMin >= hpCur(p) then return 11000 + dmgMin end
      return 3500 + dmgMax
    end

    -- Never click a damaging immunity
    if (tonumber(def.power) or 0) > 0 and eff <= 0 then return 0 end
    if effect == "PARALYZE_EFFECT" and eff <= 0 then return 0 end

    -- 1. Guaranteed KO. Prefer 100% accuracy over a roll.
    if dmgMin >= hpCur(p) and hpCur(p) > 0 then
      local score = 12000 + dmgMin + acc
      if mv.id == "QUICK_ATTACK" or (def.priority or 0) > 0
          or effect == "PRIORITY_HIT_EFFECT" then
        if theyOHKO or not weOutspeed then score = score + 800 end
      end
      -- Hyper Beam KO is fine; Hyper Beam non-KO is punished later
      return score
    end

    -- Likely KO (max roll) but not guaranteed: still good, not "free"
    if dmgMax >= hpCur(p) and hpCur(p) > 0 then
      return 9000 + acc + dmgMax * 0.25
    end

    -- 2. Explosion only as a finisher or last-gasp
    if EXPLODE_EFFECTS[effect] then
      if dmgMin >= hpCur(p) then return 11500 end
      if myHp <= 0.30 and eff > 0 then return 7200 + dmgMax end
      return 4
    end

    -- 3. Rest / Recover
    if HEAL_EFFECTS[effect] then
      if effect == "REST_EFFECT" then
        if theyOHKO and weOutspeed == false then return 0 end
        if myHp <= 0.40 then return 6400 end
        return 0
      end
      if myHp <= 0.40 then return 6800 + math.floor((1 - myHp) * 80) end
      if myHp <= 0.55 and they2HKO and weOutspeed then return 2400 end
      return 0
    end

    -- 4. Haze if they are set up
    if effect == "HAZE_EFFECT" then
      if playerBoosted then return 7800 end
      return 0
    end

    -- 5. Disable their predicted attack
    if effect == "DISABLE_EFFECT" then
      if p.disabledSlot then return 0 end
      if predDef and (tonumber(predDef.power) or 0) > 0 then
        return 5400 + (theyOHKO and 800 or 0)
      end
      return 400
    end

    -- 6. Wrap / Bind / Fire Spin / Clamp - Gen 1's real "priority"
    if TRAP_EFFECTS[effect] then
      if e.trappingTurns and e.trappingTurns > 0 then return 0 end
      if eff <= 0 then return 0 end
      -- Lock a faster threat or a setup mon
      if (not weOutspeed) or playerCanSetup or playerBoosted then
        return 6200 + (theyOHKO and 0 or 400)
      end
      if theirHp > 0.5 then return 2800 end
      return 200
    end

    -- 7. Status. Sleep is the best clock in RBY. Para if we are slower.
    --    Never status a mon we can already 2HKO unless they threaten setup.
    if STATUS_EFFECTS[effect] then
      if theirStatus then return 0 end
      if theirHp < 0.20 and not playerCanSetup then return 8 end
      local kind = STATUS_EFFECTS[effect]
      local base = 0
      if kind == "slp" then
        base = 5200
      elseif kind == "par" then
        base = weOutspeed and 3600 or 4800
      elseif kind == "confusion" then
        -- parafusion is the RBY kill combo
        base = (theirStatus == nil and statusOf(p) == nil) and 3000 or 4200
        if statusOf(p) == "par" then base = 5600 end
      elseif kind == "psn" then
        base = (theirHp > 0.6) and 2400 or 400
      else
        base = 1800
      end
      -- Anti-setup: status is worth more than a chip attack
      if playerCanSetup and myHp >= 0.5 then base = base + 900 end
      return base
    end

    -- 8. Screens before they hit us hard
    if SCREEN_EFFECTS[effect] then
      if effect == "REFLECT_EFFECT" and hasScreen(e, "reflect") then return 0 end
      if effect == "LIGHT_SCREEN_EFFECT" and hasScreen(e, "lightScreen") then return 0 end
      if theyOHKO and not weOutspeed then return 200 end
      if myHp >= 0.6 and theirHp >= 0.5 then return 3100 end
      return 200
    end

    -- 9. Substitute if healthy and they do not OHKO
    if effect == "SUBSTITUTE_EFFECT" then
      if e.substitute or e.hasSubstitute then return 0 end
      if myHp >= 0.5 and not theyOHKO then return 3000 end
      return 0
    end

    -- 10. Setup only on a free turn
    if SETUP_EFFECTS[effect] then
      if theyOHKO then return 0 end
      if they2HKO and not weOutspeed then return 0 end
      local already = boostSum(e)
      if already >= 4 then return 0 end
      if myHp >= 0.75 and (theirStatus or not playerCanSetup) then
        return 4000 + math.floor(myHp * 80) - already * 200
      end
      if myHp >= 0.90 and weOutspeed then return 2600 end
      return 0
    end

    -- 11. Speed control
    if SPEED_DOWN_EFFECTS[effect] then
      if (not weOutspeed) and (not theyOHKO) then return 3400 end
      return 30
    end

    -- 12. Leech Seed
    if effect == "LEECH_SEED_EFFECT" then
      if p.leechSeed or p.seeded then return 0 end
      if theirHp > 0.4 and myHp < 0.8 then return 2200 end
      return 80
    end

    -- 13. Mimic their best attack
    if effect == "MIMIC_EFFECT" then
      if predDef and (tonumber(predDef.power) or 0) >= 80 then return 2100 end
      return 200
    end

    -- 14. Counter: last player move was physical and chunky
    if effect == "COUNTER_EFFECT" then
      local last = p.lastMove
      local lastDef = last and defs[last]
      if lastDef and isPhysical(lastDef.type) and predDmg >= hpMax(e) * 0.3 then
        return 5000
      end
      return 10
    end

    -- 15. Hyper Beam as non-KO is a free turn for them
    if effect == "HYPER_BEAM_EFFECT" or mv.id == "HYPER_BEAM" then
      if dmgMin >= hpCur(p) then return 12000 end
      if dmgMax >= hpCur(p) then return 8000 end
      return dmgMax * 0.15
    end

    -- 16. Raw damage / 2HKO pressure
    if dmgMax > 0 then
      local hitsMin = hitsToKO(dmgMin, p)
      local score = dmgMax
      if hitsMin <= 2 then score = score + 1800 end
      if theirHp <= 0.25 then score = score * 1.35 end
      score = score + acc * 0.2
      -- Don't chip when we should be stopping a setup
      if playerCanSetup and myHp >= 0.6 and hitsMin > 2 then
        score = score * 0.6
      end
      return score
    end

    return 15
  end

  local function pickBestMove(battle)
    local best, bestScore
    for _, row in ipairs(usableMoves(battle)) do
      local s = scoreMove(battle, row.mv)
      if s > 0 and (not bestScore or s > bestScore) then
        best, bestScore = row.mv, s
      end
    end
    return best, bestScore or 0
  end

  local function weCanKO(battle)
    local _, score = pickBestMove(battle)
    return score >= 12000
  end

  ---------------------------------------------------------------------
  -- Switch-in scoring
  ---------------------------------------------------------------------
  local function partyMonBattlerProxy(mon, data)
    return {
      mon = mon,
      curTypes = speciesTypes(data, mon),
      curMoves = mon.moves or mon.curMoves,
      stats = mon.stats,
      stages = mon.stages or {},
    }
  end

  local function switchInScore(battle, mon, predMoveDef)
    if not mon or (mon.hp or 0) <= 0 then return -999 end
    local data = battle.data
    local proxy = partyMonBattlerProxy(mon, data)
    local p = battle.player
    local score = 0

    local incoming = 0
    if predMoveDef then
      incoming = estimateDamage(data, p, proxy, predMoveDef)
    end
    local max = (mon.stats and mon.stats.hp) or mon.maxHp or 1
    local hp = mon.hp or max
    if incoming >= hp then
      score = score - 18
    elseif incoming * 2 >= hp then
      score = score - 2
    elseif incoming * 4 < hp then
      score = score + 3
    end

    if predMoveDef then
      local eff = effectiveness(data, predMoveDef.type, typesOf(proxy, data))
      if eff == 0 then score = score + 18
      elseif eff < 1 then score = score + 8
      elseif eff > 1 then score = score - 5
      end
    end

    if speedOf(proxy) > speedOf(p) then score = score + 14 end

    local defs = data and data.moves
    local listed = mon.moves or mon.curMoves
    if type(listed) == "table" and type(defs) == "table" then
      local bestOff = 0
      for _, mv in ipairs(listed) do
        local id = type(mv) == "table" and mv.id or mv
        local def = defs[id]
        if def then
          local d = estimateDamage(data, proxy, p, def, { minRoll = true })
          if d > bestOff then bestOff = d end
        end
      end
      if bestOff >= hpCur(p) then score = score + 8
      elseif bestOff > 0 then score = score + 2
      end
    end

    return score
  end

  local function resistAllBonus(battle, mon)
    local p = battle.player
    local data = battle.data
    local defs = data and data.moves
    if not (p and type(p.curMoves) == "table" and defs) then return 0 end
    local proxy = partyMonBattlerProxy(mon, data)
    local worst = 1
    local any = false
    for i, mv in ipairs(p.curMoves) do
      if p.disabledSlot ~= i then
        local def = defs[mv.id]
        if def and (tonumber(def.power) or 0) > 0 then
          any = true
          local eff = effectiveness(data, def.type, typesOf(proxy, data))
          if eff > worst then worst = eff end
        end
      end
    end
    if not any then return 0 end
    if worst == 0 then return 17 end
    if worst < 1 then return 10 end
    if worst > 1 then return -6 end
    return 0
  end

  local function bestSwitchIndex(battle)
    local party = battle.enemyParty
    local cur = battle.enemyIndex or 1
    if type(party) ~= "table" then return nil, -999 end
    local _, _, predDef = bestPlayerAttack(battle)
    local bestI, bestS
    for i, mon in ipairs(party) do
      if i ~= cur and mon and (mon.hp or 0) > 0 then
        local s = switchInScore(battle, mon, predDef) + resistAllBonus(battle, mon)
        if not bestS or s > bestS then
          bestI, bestS = i, s
        end
      end
    end
    return bestI, bestS or -999
  end

  local function currentMatchupScore(battle)
    local e = battle.enemy and battle.enemy.mon
    if not e then return -999 end
    local _, _, predDef = bestPlayerAttack(battle)
    return switchInScore(battle, e, predDef) + resistAllBonus(battle, e)
  end

  local function onlyBadMovesLeft(battle)
    local p, e = battle.player, battle.enemy
    local defs = battle.data and battle.data.moves
    if not defs then return false end
    local anyDamage, anyUseful = false, false
    for _, row in ipairs(usableMoves(battle)) do
      local def = defs[row.mv.id]
      if def then
        local effect = def.effect
        if STATUS_EFFECTS[effect] and not statusOf(p) then
          anyUseful = true
        elseif HEAL_EFFECTS[effect] and hpFrac(e) <= 0.5 then
          anyUseful = true
        elseif TRAP_EFFECTS[effect] then
          anyUseful = true
        elseif SETUP_EFFECTS[effect] and hpFrac(e) >= 0.75 then
          anyUseful = true
        elseif (tonumber(def.power) or 0) > 0 then
          anyDamage = true
          local dmg = estimateDamage(battle.data, e, p, def, { minRoll = true })
          if hitsToKO(dmg, p) <= 3 then anyUseful = true end
        end
      end
    end
    return anyDamage and not anyUseful
  end

  local function playerThreatensKO(battle)
    local _, dmg = predictedPlayerMove(battle)
    return dmg >= hpCur(battle.enemy)
  end

  local function playerThreatens2HKO(battle)
    local _, dmg = predictedPlayerMove(battle)
    return dmg * 2 >= hpCur(battle.enemy)
  end

  local function livingBackups(battle)
    local party = battle.enemyParty
    local cur = battle.enemyIndex or 1
    local n = 0
    if type(party) ~= "table" then return 0 end
    for i, mon in ipairs(party) do
      if i ~= cur and mon and (mon.hp or 0) > 0 then n = n + 1 end
    end
    return n
  end

  local function switchKey(battle)
    return tostring(trainerClass(battle) or "t") .. ":" .. tostring(battle.enemyIndex or 0)
  end

  local function wantSwitch(battle)
    if livingBackups(battle) < 1 then return nil end
    if weCanKO(battle) then return nil end

    local idx, inScore = bestSwitchIndex(battle)
    if not idx then return nil end
    local here = currentMatchupScore(battle)
    local gap = brutal() and 3 or 6
    if inScore < here + gap then return nil end

    local e = battle.enemy
    local redBar = hpFrac(e) <= 0.20
    local _, _, predDef = bestPlayerAttack(battle)

    -- 1. Type immunity to the predicted move (RBY stand-in for absorb abilities)
    if predDef then
      local bench = battle.enemyParty[idx]
      local benchEff = effectiveness(battle.data, predDef.type, speciesTypes(battle.data, bench))
      local hereEff = effectiveness(battle.data, predDef.type, typesOf(e, battle.data))
      if benchEff == 0 and hereEff > 0 then
        return idx, "absorb-immunity"
      end
    end

    -- 2. Only bad moves left
    if onlyBadMovesLeft(battle) then
      return idx, "bad-moves"
    end

    -- 3. Avoid death (RR skips this in the red)
    if not redBar then
      local theyOutspeed = speedOf(battle.player) >= speedOf(e)
      if theyOutspeed and playerThreatensKO(battle) then
        return idx, "avoid-death"
      end
      if theyOutspeed and playerThreatens2HKO(battle) and hpFrac(e) <= 0.60 then
        return idx, "avoid-2hko"
      end
      -- Brutal: even if we outspeed, pivot off a 4x weakness
      if brutal() and predDef then
        local hereEff = effectiveness(battle.data, predDef.type, typesOf(e, battle.data))
        if hereEff >= 2 and inScore >= here + 8 then
          return idx, "pivot-weakness"
        end
      end
    end

    -- 4. Save sweeper
    local hasSetup = kitHas(battle.data, e, function(def)
      return SETUP_EFFECTS[def.effect]
    end)
    if hasSetup and hpFrac(e) >= 0.70 and here <= 4 and inScore >= 12 then
      return idx, "save-sweeper"
    end

    -- 5. Brutal: they just set up and we have a better answer
    if brutal() and boostSum(battle.player) >= 2 and inScore >= here + 5 then
      return idx, "answer-boosts"
    end

    return nil
  end

  ---------------------------------------------------------------------
  -- Items
  ---------------------------------------------------------------------
  local function smarterItem(battle, vanilla)
    if type(vanilla) ~= "table" or vanilla.special ~= "aiItem" then
      return nil
    end
    local item = vanilla.item
    if not item then return vanilla end
    local e = battle.enemy
    local heal = POTIONS[item]
    if item == "FULL_HEAL" or item == "FULL_RESTORE" then
      local st = statusOf(e)
      if not st then
        if item == "FULL_RESTORE" and hpFrac(e) <= 0.45 then return vanilla end
        return nil
      end
      return vanilla
    end
    if heal then
      if weCanKO(battle) then return nil end
      if hpFrac(e) > 0.50 then return nil end
      local _, pred = predictedPlayerMove(battle)
      if pred >= hpCur(e) and pred < hpCur(e) + heal then
        return vanilla
      end
      if hpFrac(e) <= 0.35 then return vanilla end
      return nil
    end
    if item == "X_ACCURACY" then
      -- OHKO / low-acc set on a healthy mon
      if hpFrac(e) >= 0.7 and not playerThreatensKO(battle) then return vanilla end
      return nil
    end
    if item == "X_SPEED" then
      if speedOf(e) <= speedOf(battle.player) and hpFrac(e) >= 0.6 then
        return vanilla
      end
      return nil
    end
    if item == "GUARD_SPEC" then
      if hpFrac(e) >= 0.75 and not playerThreatensKO(battle) then return vanilla end
      return nil
    end
    if tostring(item):sub(1, 2) == "X_" then
      if hpFrac(e) >= 0.70 and not playerThreatensKO(battle) then return vanilla end
      return nil
    end
    return vanilla
  end

  ---------------------------------------------------------------------
  -- On-faint send-in
  ---------------------------------------------------------------------
  local function applyOnFaintSendIn(battle)
    if type(battle) ~= "table" or battle.kind ~= "trainer" then return end
    if not enabledFor(battle) then return end
    local party = battle.enemyParty
    if type(party) ~= "table" then return end
    local _, _, predDef = bestPlayerAttack(battle)
    local firstLiving, bestI, bestS
    for i, mon in ipairs(party) do
      if mon and (mon.hp or 0) > 0 then
        if not firstLiving then firstLiving = i end
        local s = switchInScore(battle, mon, predDef) + resistAllBonus(battle, mon)
        if not bestS or s > bestS then
          bestI, bestS = i, s
        end
      end
    end
    if not bestI or not firstLiving or bestI == firstLiving then return end
    party[firstLiving], party[bestI] = party[bestI], party[firstLiving]
    switchedThisMon = {}
    switchCount = {}
  end

  ---------------------------------------------------------------------
  -- Lead selection: reorder trainer.party so slot 1 answers the player's lead
  ---------------------------------------------------------------------
  local function scoreSpeciesVsLead(data, species, playerLead)
    if not species or not playerLead then return 0 end
    local ourTypes = speciesTypes(data, { species = species })
    local theirTypes = speciesTypes(data, playerLead)
    local score = 0
    -- Resist their STABs
    for _, t in ipairs(theirTypes) do
      local eff = effectiveness(data, t, ourTypes)
      if eff == 0 then score = score + 18
      elseif eff < 1 then score = score + 8
      elseif eff > 1 then score = score - 8
      end
    end
    -- Hit them with our STABs
    for _, t in ipairs(ourTypes) do
      local eff = effectiveness(data, t, theirTypes)
      if eff > 1 then score = score + 6
      elseif eff == 0 then score = score - 4
      end
    end
    return score
  end

  ---------------------------------------------------------------------
  -- Hooks
  ---------------------------------------------------------------------
  mod.hooks:wrap("trainer.before_battle", function(nextFn, game, context, continue)
    pendingPlayerLead = nil
    local party = game and game.save and game.save.party
    if type(party) == "table" then
      for _, mon in ipairs(party) do
        if mon and (mon.hp or 0) > 0 then
          pendingPlayerLead = mon
          break
        end
      end
    end
    return nextFn(game, context, continue)
  end)

  mod.events:on("battle.started", function()
    switchedThisMon = {}
    switchCount = {}
  end)

  mod.hooks:wrap("battle.exp_award", function(nextAward, ctx)
    nextAward(ctx)
    if ctx and ctx.battle then
      applyOnFaintSendIn(ctx.battle)
    end
  end)

  mod.hooks:wrap("battle.enemy_action", function(nextAction, battle)
    local action = nextAction(battle)

    if type(battle) ~= "table" or battle.kind ~= "trainer" or not battle.trainer then
      return action
    end
    if not enabledFor(battle) then
      return action
    end

    if type(action) == "table" and action.struggle then return action end
    local e = battle.enemy
    if e and (e.mustRecharge or e.charging or e.rageMove or e.bideTurns
        or (e.thrashTurns or 0) > 0 or (e.trappingTurns or 0) > 0) then
      return action
    end
    if not (e and battle.player and e.mon and battle.player.mon) then
      return action
    end

    local mode = modeOf()

    if mode == "full" and type(action) == "table" and action.special == "aiItem" then
      local item = smarterItem(battle, action)
      if item then return item end
    elseif type(action) == "table" and action.special ~= nil then
      if mode == "moves" then return action end
      if action.special == "aiSwitch" then
        local idx = bestSwitchIndex(battle)
        if idx then
          action = { special = "aiSwitch", index = idx }
        end
        return action
      end
      if action.special ~= "aiItem" then
        return action
      end
    end

    if mode == "switch" or mode == "full" then
      local key = switchKey(battle)
      local cap = brutal() and 2 or 1
      local used = switchCount[key] or 0
      if used < cap and not switchedThisMon[key] then
        local idx, why = wantSwitch(battle)
        if idx then
          switchedThisMon[key] = why or true
          switchCount[key] = used + 1
          return { special = "aiSwitch", index = idx }
        end
      end
    end

    local best = pickBestMove(battle)
    return best or action
  end)

  -- Real lead reorder happens here: once the battle exists we still
  -- cannot unsend slot 1, but trainer.party can run with battle data
  -- if a later engine pass re-asks. Primary lead logic uses type chart
  -- from a stash filled when the first trainer battle starts, then
  -- applied on the NEXT trainer via pending reorder of the raw party
  -- list. To make the FIRST fight also lead-smart we wrap trainer.party
  -- again after trying to read data off the lead mon's species through
  -- a game-level cache.
  local gameData
  mod.events:on("game.ready", function(ev)
    gameData = ev and ev.game and ev.game.data
  end)

  -- Re-wrap trainer.party with data-aware scoring by replacing the
  -- earlier no-op: register a second wrap that actually sorts.
  mod.hooks:wrap("trainer.party", function(nextParty, oppClass, partyIndex, party)
    local out = nextParty(oppClass, partyIndex, party) or party
    if opt("scope", "bosses") ~= "all" and not isBossClass(oppClass) then
      return out
    end
    if not brutal() then return out end
    if type(out) ~= "table" or #out < 2 then return out end
    local lead = pendingPlayerLead
    local data = gameData
    if not (lead and data and data.pokemon and data.type_chart) then
      return out
    end
    local bestI, bestS = 1, scoreSpeciesVsLead(data, out[1] and out[1].species, lead)
    for i = 2, #out do
      local slot = out[i]
      local s = scoreSpeciesVsLead(data, slot and slot.species, lead)
      if s > bestS + 4 then
        bestI, bestS = i, s
      end
    end
    if bestI == 1 then return out end
    local copy = {}
    for i, slot in ipairs(out) do copy[i] = slot end
    copy[1], copy[bestI] = copy[bestI], copy[1]
    return copy
  end)

  mod.log:info("rr_style_ai: brutal RBY trainer AI armed")
end
