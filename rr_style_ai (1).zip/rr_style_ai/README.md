# RR-Style Trainer AI (RBY)

Smarter trainer AI for Red, Blue, and Yellow in Gen1Recomp.

Not a line-for-line Radical Red port. Same decision order on Gen 1 rules:
min-roll KO checks, anti-setup, Wrap/Disable/Haze, smart leads, on-faint
send-ins, and item use on Full mode. Wild battles stay vanilla.

## Options (F10 mod manager)

- AI MODE: Moves only / Moves + Switch / Full (switch + items)
- APPLY TO: Gym / E4 / Rival, or all trainers
- INTENSITY: Smart or Brutal (default)

Default: Full + Brutal on gyms, Elite Four, Giovanni, and rivals.

## Install

Copy the rr_style_ai folder into mods/, or import the zip from MODS.
Enable it. Start a Red, Blue, or Yellow file.

Works next to rr_boss_teams and xp_rate. Priority 80 if another mod
also wraps battle.enemy_action.
